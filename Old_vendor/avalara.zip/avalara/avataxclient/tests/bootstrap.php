<?php

// Grab our autoloader
require __DIR__.'/../vendor/autoload.php';

// Include the AvaTaxClient library directly so we can test this branch specifically
require_once __DIR__.'/../src/AvaTaxClient.php';


?>